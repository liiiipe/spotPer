/*
Segundo script de cria��o do banco de dados BDSpotPer
(Quest�es 2)
*/

USE BDSpotPer;

/*CREATE TABLE playlist
	(
		cod_playlist INT IDENTITY (1, 1)
			CONSTRAINT playlist_PK PRIMARY KEY (cod_playlist),
		nome_da_playlist VARCHAR(50),
		data_de_criacao DATE DEFAULT GETDATE()
	) ON BDSpotPer_fg02

CREATE TABLE gravadora 
	(
		cod_gravadora INT NOT NULL
			CONSTRAINT gravadora_PK PRIMARY KEY (cod_gravadora),
		nome_gravadora VARCHAR(50) NOT NULL,
		endereco VARCHAR(50) NOT NULL,
		site_gravadora VARCHAR(50) NOT NULL,
	) ON BDSpotPer_fg01

CREATE TABLE telefones
	(
		numero VARCHAR(20) NOT NULL,
		cod_gravadora INT NOT NULL
			CONSTRAINT telefones_FK FOREIGN KEY (cod_gravadora) REFERENCES gravadora,
			CONSTRAINT telefones_PK PRIMARY KEY (numero, cod_gravadora),
	) ON BDSpotPer_fg01

CREATE TABLE periodo_musical
	(
		cod_periodo INT NOT NULL
			CONSTRAINT cod_periodo_PK PRIMARY KEY (cod_periodo),
		intervalo VARCHAR(10) NOT NULL,
		descricao VARCHAR(50) NOT NULL
	) ON BDSpotPer_fg01
	
CREATE TABLE compositor
	(
		cod_compositor INT NOT NULL
			CONSTRAINT compositor_PK PRIMARY KEY (cod_compositor),
		local_de_nascimento VARCHAR(50) NOT NULL,
		nome_compositor VARCHAR(50) NOT NULL,
		data_de_morte DATE,
		data_de_nascimento DATE NOT NULL,
		cod_periodo INT NOT NULL
			CONSTRAINT compositor_FK FOREIGN KEY (cod_periodo) REFERENCES periodo_musical
	) ON BDSpotPer_fg01

CREATE TABLE interprete
	(
		cod_interprete INT NOT NULL
			CONSTRAINT interprete_PK PRIMARY KEY (cod_interprete),
		tipo_interprete VARCHAR(20) NOT NULL,
		nome_interprete VARCHAR(50) NOT NULL,
	) ON BDSpotPer_fg01

CREATE TABLE album
	(
		cod_album INT NOT NULL
			CONSTRAINT album_PK PRIMARY KEY (cod_album),
		data_de_compra DATE NOT NULL,
		data_de_gravacao DATE NOT NULL,
		preco_de_compra INT NOT NULL,
		descricao_album VARCHAR(50) NOT NULL,
		tipo_de_compra VARCHAR(10) NOT NULL,
		cod_gravadora INT NOT NULL
			CONSTRAINT album_FK FOREIGN KEY (cod_gravadora) REFERENCES gravadora,
	) ON BDSpotPer_fg01

CREATE TABLE composicao
	(
		cod_composicao INT NOT NULL
			CONSTRAINT composicao_PK PRIMARY KEY (cod_composicao),
		descricao VARCHAR(100) NOT NULL
	) ON BDSpotPer_fg01

CREATE TABLE faixa
	(
		numero_faixa INT NOT NULL,
		cod_album INT NOT NULL
			CONSTRAINT faixa_album_FK FOREIGN KEY (cod_album) REFERENCES album,
		cod_composicao INT NOT NULL
			CONSTRAINT faixa_composicao_FK FOREIGN KEY (cod_composicao) REFERENCES composicao,
			CONSTRAINT faixas_PK PRIMARY KEY (cod_album, numero_faixa),
		descricao VARCHAR(50) NOT NULL,
		tempo_de_execucao INT NOT NULL,
		tipo_de_gravacao VARCHAR(50) NOT NULL,
	) ON BDSpotPer_fg02


CREATE TABLE faixa_playlist 
	(
		numero_de_tocadas INT DEFAULT 0,
		data_ultima_toca DATE,
		cod_album INT NOT NULL,
		numero_faixa INT NOT NULL
			CONSTRAINT faixa_playlist_faixa_FK FOREIGN KEY (cod_album, numero_faixa) REFERENCES faixa,
		cod_playlist INT NOT NULL
			CONSTRAINT faixa_playlist_playlist_FK FOREIGN KEY (cod_playlist) REFERENCES playlist,
			CONSTRAINT faixa_playlist_PK PRIMARY KEY (cod_album, numero_faixa, cod_playlist)
	) ON BDSpotPer_fg02


CREATE TABLE faixa_interprete
	(
		cod_interprete INT NOT NULL
			CONSTRAINT interprete_faixa_FK FOREIGN KEY (cod_interprete) REFERENCES interprete,
		cod_album INT NOT NULL,
		numero_faixa INT NOT NULL,
			CONSTRAINT faixa_interprete_FK FOREIGN KEY (cod_album, numero_faixa) REFERENCES faixa,
			CONSTRAINT faixa_interprete_PK PRIMARY KEY (cod_interprete, cod_album, numero_faixa)
	) ON BDSpotPer_fg01

CREATE TABLE faixa_compositor
	(
		cod_compositor INT NOT NULL
			CONSTRAINT compositor_faixa_FK FOREIGN KEY (cod_compositor) REFERENCES compositor,
		cod_album INT NOT NULL,
		numero_faixa INT NOT NULL,
			CONSTRAINT faixa_compositor_FK FOREIGN KEY (cod_album, numero_faixa) REFERENCES faixa,
			CONSTRAINT faixa_compositor_PK PRIMARY KEY (cod_compositor, cod_album, numero_faixa)
	) ON BDSpotPer_fg01
	*/