/*
Script de restri��es do banco de dados BDSpotPer
*/

USE BDSpotPer;

--Restri��o referente a: Part I (i) c
ALTER TABLE album
ADD CONSTRAINT data_compra_limit CHECK(data_de_compra > '01-01-2000');

--Restri��o referente a: Part I (i) e)
CREATE TRIGGER preco_album_limit_TR ON album
INSTEAD OF INSERT AS
IF (SELECT preco_de_compra FROM inserted) > 3 * 
(SELECT AVG(preco_de_compra) FROM album
	WHERE NOT EXISTS (SELECT faixa.cod_album FROM faixa WHERE tipo_de_gravacao = 'ADD' AND album.cod_album = faixa.cod_album))
 BEGIN
	RAISERROR('O pre�o de compra de um �lbum n�o dever ser superior a tr�s vezes a
m�dia do pre�o de compra de �lbuns, com todas as faixas com tipo de
grava��o DDD.', 10, 1)
	ROLLBACK TRANSACTION
 END
ELSE
 BEGIN
	INSERT INTO album SELECT * FROM inserted
 END

--Restri��o referente a: Part I (ii) b)
ALTER TABLE faixa
ADD CONSTRAINT restri_tipos_gravacao CHECK(tipo_de_gravacao = 'DDD' OR tipo_de_gravacao = 'ADD');

--Restri��o referente a: Part II 3) a)

CREATE TRIGGER TR_album_faixa_periodo_tipograva ON faixa_compositor
INSTEAD OF INSERT AS
IF (SELECT periodo_musical.descricao FROM inserted INNER JOIN compositor
	ON compositor.cod_compositor = inserted.cod_compositor INNER JOIN periodo_musical
	ON compositor.cod_periodo = periodo_musical.cod_periodo) = 'Barroco' AND 
	(SELECT tipo_de_gravacao FROM inserted INNER JOIN faixa
	ON faixa.cod_album = inserted.cod_album AND faixa.numero_faixa = inserted.numero_faixa) != 'DDD'
 BEGIN
 	 RAISERROR('Um �lbum, com faixas de m�sicas do per�odo barroco, s� pode ser adquirido, caso o tipo de grava��o seja DDD.', 10, 1)
 	 ROLLBACK TRANSACTION
 END
ELSE
 BEGIN
	INSERT INTO faixa_compositor SELECT * FROM inserted
 END



--Restri��o referente a: Part II 3) b)
CREATE TRIGGER limit_faixas_album_TR ON faixa
INSTEAD OF INSERT AS
IF (SELECT COUNT(faixa.cod_album) FROM inserted INNER JOIN faixa ON faixa.cod_album = inserted.cod_album) >= 64
 BEGIN
	RAISERROR('Um �lbum n�o pode ter mais que 64 faixas', 10, 1)
	ROLLBACK TRANSACTION
 END
ELSE
 BEGIN
	INSERT INTO faixa SELECT * FROM inserted
 END

--Restri��es referentes a: Part II 3) c)
ALTER TABLE faixa
DROP CONSTRAINT faixa_album_FK;

ALTER TABLE faixa
ADD CONSTRAINT faixa_album_FK FOREIGN KEY (cod_album) REFERENCES album
ON DELETE CASCADE
ON UPDATE CASCADE;

ALTER TABLE faixa_playlist
DROP CONSTRAINT faixa_playlist_faixa_FK;

ALTER TABLE faixa_playlist
ADD CONSTRAINT faixa_playlist_faixa_FK FOREIGN KEY (cod_album, numero_faixa) REFERENCES faixa
ON DELETE CASCADE
ON UPDATE CASCADE;

ALTER TABLE faixa_interprete
DROP CONSTRAINT faixa_interprete_FK;

ALTER TABLE faixa_interprete
ADD CONSTRAINT faixa_interprete_FK FOREIGN KEY (cod_album, numero_faixa) REFERENCES faixa
ON DELETE CASCADE
ON UPDATE CASCADE;

ALTER TABLE faixa_compositor
DROP CONSTRAINT faixa_compositor_FK;

ALTER TABLE faixa_compositor
ADD CONSTRAINT faixa_compositor_FK FOREIGN KEY (cod_album, numero_faixa) REFERENCES faixa
ON DELETE CASCADE
ON UPDATE CASCADE;

