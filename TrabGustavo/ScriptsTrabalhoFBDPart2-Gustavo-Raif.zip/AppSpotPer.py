#Importando biblio de interface gráfica
from tkinter import *

#Importando pyodbc módulo
import pyodbc as db

from functools import partial

#Conectando com banco de dados e criando cursor
con = db.connect('DRIVER={ODBC Driver 17 for SQL Server};SERVER=AL4N\SQLEXPRESS;Trusted_Connection=yes;DATABASE=BDSpotPer')
cur = con.cursor()

#Funções


def convertTime(segundos):
    m = 0
    while segundos > 60:
        segundos = segundos - 60
        m = m + 1
    return str(m)+":"+str(segundos)


def all_children (window) :
    _list = window.winfo_children()

    for item in _list :
        if item.winfo_children() :
            _list.extend(item.winfo_children())

    return _list                 

def getInfoFaixas():
    mainArea.config(text="")
    
    widget_list = all_children(mainArea)
    for item in widget_list:
        item.destroy()
    
    tabN = Label(mainArea, width=5, text="#", relief = RIDGE, borderwidth = '3')
    tabN.grid(row = 0, column = 1)
    tabNome = Label(mainArea, width=60, text="nome", relief = RIDGE, borderwidth = '3')
    tabNome.grid(row = 0, column = 2)
    tabAlbum = Label(mainArea, width=40, text="Album", relief = RIDGE, borderwidth = '3')
    tabAlbum.grid(row = 0, column = 3)
    tabFaixaN = Label(mainArea, width=5, text="Faixa", relief = RIDGE, borderwidth = '3')
    tabFaixaN.grid(row = 0, column = 4)
    tabGen = Label(mainArea, width=10, text="Gênero", relief = RIDGE, borderwidth = '3')
    tabGen.grid(row = 0, column = 5)
    tabCom = Label(mainArea, width=20, text="Compositor", relief = RIDGE, borderwidth = '3')
    tabCom.grid(row = 0, column = 6)
    tabTemp = Label(mainArea, width=10, text="Tempo total", relief = RIDGE, borderwidth = '3')
    tabTemp.grid(row = 0, column = 7)
    tabTipgv = Label(mainArea, width=10, text="gravação", relief = RIDGE, borderwidth = '3')
    tabTipgv.grid(row = 0, column = 8)
    
    cur.execute('EXEC faixas_info')
    row = cur.fetchone()
    contRows = 1
    while row:
        numero = Label(mainArea, width = 5, text=str(contRows), relief='solid', borderwidth = '1')
        numero.grid(row = contRows, column = 1)
        
        nomeFaixa = Label(mainArea, width = 60, text=str(row[0]), relief='solid', borderwidth = '1')
        nomeFaixa.grid(row = contRows, column = 2)

        album = Label(mainArea, width = 40, text=str(row[1]), relief='solid', borderwidth = '1')
        album.grid(row = contRows, column = 3)

        faixaN = Label(mainArea, width = 5, text=str(row[2]), relief='solid', borderwidth = '1')
        faixaN.grid(row = contRows, column = 4)

        gen = Label(mainArea, width = 10, text=str(row[3]), relief='solid', borderwidth = '1')
        gen.grid(row = contRows, column = 5)

        com = Label(mainArea, width = 20, text=str(row[4]), relief='solid', borderwidth = '1')
        com.grid(row = contRows, column = 6)

        temp = Label(mainArea, width = 10, text=convertTime(int(row[5])), relief='solid', borderwidth = '1')
        temp.grid(row = contRows, column = 7)

        tipgv = Label(mainArea, width = 10, text=str(row[6]), relief='solid', borderwidth = '1')
        tipgv.grid(row = contRows, column = 8)
        
        contRows = contRows + 1
        row = cur.fetchone()


def getInfoAlbuns():
    mainArea.config(text="")
    
    widget_list = all_children(mainArea)
    for item in widget_list:
        item.destroy()

    btnAttAlbum = Button(mainArea, width=130, text="ATUALIZAR UM ALBUM", bg="white", command=novaAlbumCampo)
    btnAttAlbum.grid(row = 0, column = 0, columnspan=100)
    
    tabN = Label(mainArea, width=5, text="#", relief = RIDGE, borderwidth = '3')
    tabN.grid(row = 1, column = 1)
    tabNome = Label(mainArea, width=40, text="nome", relief = RIDGE, borderwidth = '3')
    tabNome.grid(row = 1, column = 2)
    tabDataGrav = Label(mainArea, width=20, text="data de gravação", relief = RIDGE, borderwidth = '3')
    tabDataGrav.grid(row = 1, column = 3)
    tabDataCom = Label(mainArea, width=20, text="data de compra", relief = RIDGE, borderwidth = '3')
    tabDataCom.grid(row = 1, column = 4)
    tabVal = Label(mainArea, width=10, text="valor", relief = RIDGE, borderwidth = '3')
    tabVal.grid(row = 1, column = 5)
    tabTipCom = Label(mainArea, width=10, text="compra", relief = RIDGE, borderwidth = '3')
    tabTipCom.grid(row = 1, column = 6)
    tabGrav = Label(mainArea, width=20, text="gravadora", relief = RIDGE, borderwidth = '3')
    tabGrav.grid(row = 1, column = 7)


    cur.execute('EXEC albuns_info')
    row = cur.fetchone()
    contRows = 2
    while row:
        numero = Label(mainArea, width = 5, text=str(contRows - 1), relief='solid', borderwidth = '2')
        numero.grid(row = contRows, column = 1)
        
        nomeAlbum = Button(mainArea, width = 40, text=str(row[0]), relief='solid', borderwidth = '1')
        nomeAlbum["command"] = partial(carregarAlgum, int(row[6]))
        nomeAlbum.grid(row = contRows, column = 2)

        dataGrav = Label(mainArea, width = 20, text=str(row[1]), relief='solid', borderwidth = '2')
        dataGrav.grid(row = contRows, column = 3)

        dataCom = Label(mainArea, width = 20, text=str(row[2]), relief='solid', borderwidth = '2')
        dataCom.grid(row = contRows, column = 4)

        val = Label(mainArea, width = 10, text="R$"+str(row[3]), relief='solid', borderwidth = '2')
        val.grid(row = contRows, column = 5)

        tipoCom = Label(mainArea, width = 10, text=str(row[4]), relief='solid', borderwidth = '2')
        tipoCom.grid(row = contRows, column = 6)

        grav = Label(mainArea, width = 20, text=(row[5]), relief='solid', borderwidth = '2')
        grav.grid(row = contRows, column = 7)

        
        contRows = contRows + 1
        row = cur.fetchone()


def getInfoPlaylists():
    mainArea.config(text="")
    
    widget_list = all_children(mainArea)
    for item in widget_list:
        item.destroy()

    btnNwPlaylist = Button(mainArea, width=130, text="NOVA PLAYLIST", bg="white", command=novaPlaylistCampo)
    btnNwPlaylist.grid(row = 0, column = 0, columnspan=100)

    tabN = Label(mainArea, width=5, text="#", relief = RIDGE, borderwidth = '3')
    tabN.grid(row = 1, column = 1)
    tabNome = Label(mainArea, width=60, text="nome", relief = RIDGE, borderwidth = '3')
    tabNome.grid(row = 1, column = 2)
    tabDataCri = Label(mainArea, width=20, text="data de criação", relief = RIDGE, borderwidth = '3')
    tabDataCri.grid(row = 1, column = 3)
    tabTocadas = Label(mainArea, width=10, text="tocadas", relief = RIDGE, borderwidth = '3')
    tabTocadas.grid(row = 1, column = 4)
    tabDataTocada = Label(mainArea, width=20, text="ultima tocada", relief = RIDGE, borderwidth = '3')
    tabDataTocada.grid(row = 1, column = 5)

    cur.execute('EXEC playlists_info')
    row = cur.fetchone()
    contRows = 2
    while row:
        numero = Label(mainArea, width = 5, text=str(contRows - 1), relief='solid', borderwidth = '2')
        numero.grid(row = contRows, column = 1)
        
        nomePlaylist = Button(mainArea, width = 60, height=1, text=str(row[0]), relief='solid', borderwidth = '1')
        nomePlaylist["command"] = partial(cerregarPlaylist, int(row[5]))
        nomePlaylist.grid(row = contRows, column = 2)

        dataCri = Label(mainArea, width = 20, text=str(row[1]), relief='solid', borderwidth = '2')
        dataCri.grid(row = contRows, column = 3)

        tocadas = Label(mainArea, width = 10, text=str(row[2]), relief='solid', borderwidth = '2')
        tocadas.grid(row = contRows, column = 4)

        dataTocadas = Label(mainArea, width = 20, text=str(row[3]), relief='solid', borderwidth = '2')
        dataTocadas.grid(row = contRows, column = 5)
        
        contRows = contRows + 1
        row = cur.fetchone()
        
def novaPlaylistCampo():
    mainArea.config(text="")
    
    widget_list = all_children(mainArea)
    for item in widget_list:
        item.destroy()

    tituloGrande = Label(mainArea, width=150, text="Digite um nome para uma nova playlist!", relief = RIDGE, borderwidth = '3')
    tituloGrande.grid(row = 0, column = 0, columnspan = 100)


    tituloEntrada = Label(mainArea, width = 10, text='Nome:')
    tituloEntrada.grid(row = 1, column = 0)

    entrada = Entry(mainArea)
    entrada.grid(row = 1, column = 1)

    btEnviarNomePlaylist = Button(mainArea, width=20, text="enviar")
    btEnviarNomePlaylist["command"] = partial(enviarNomePlaylist, entrada)
    btEnviarNomePlaylist.grid(row = 1, column = 2)

def enviarNomePlaylist(entrada):
    nome = entrada.get()
    if nome == "":
        resposta = Label(mainArea, width = 30, text='Entre um nome válido')
        resposta.grid(row = 1, column = 0)
    else:
        cur.execute('EXEC crear_nova_playlist '+nome)
        cur.commit()
        resposta2 = Label(mainArea, width = 10, text='Playlist criada!')
        resposta2.grid(row = 1, column = 0)

def cerregarPlaylist(cod):
    mainArea.config(text="")
    
    widget_list = all_children(mainArea)
    for item in widget_list:
        item.destroy()

    cur.execute('EXEC pegar_nome_playlist '+str(cod))
    nome = cur.fetchone()

    titulo = Label(mainArea, width=150, text=str(nome[0]), relief = RIDGE, borderwidth = '3')
    titulo.grid(row = 0, column = 0, columnspan = 100)

    tabN = Label(mainArea, width=5, text="#", relief = RIDGE, borderwidth = '3')
    tabN.grid(row = 1, column = 1)
    tabNome = Label(mainArea, width=60, text="musica", relief = RIDGE, borderwidth = '3')
    tabNome.grid(row = 1, column = 2)
    tabAlbum = Label(mainArea, width=40, text="album", relief = RIDGE, borderwidth = '3')
    tabAlbum.grid(row = 1, column = 3)
    tabFaixa = Label(mainArea, width=5, text="faixa", relief = RIDGE, borderwidth = '3')
    tabFaixa.grid(row = 1, column = 4)
    tabGen = Label(mainArea, width=10, text="gênero", relief = RIDGE, borderwidth = '3')
    tabGen.grid(row = 1, column = 5)
    tabCom = Label(mainArea, width=20, text="compositor", relief = RIDGE, borderwidth = '3')
    tabCom.grid(row = 1, column = 6)
    tabTemp = Label(mainArea, width=10, text="temp de exexc", relief = RIDGE, borderwidth = '3')
    tabTemp.grid(row = 1, column = 7)
    tabTipgv = Label(mainArea, width=10, text="compositor", relief = RIDGE, borderwidth = '3')
    tabTipgv.grid(row = 1, column = 8)

    cur.execute('EXEC carregar_playlist '+str(cod))
    row = cur.fetchone()
    contRows = 2
    if(str(row) == 'None'):
        resp = Label(mainArea, width=150, text='Playlist vazia...', relief = 'solid', borderwidth = '1')
        resp.grid(row = 2, column = 0, columnspan = 100)
    
    else:
        while row:
            numero = Label(mainArea, width = 5, text=str(contRows - 1), relief='solid', borderwidth = '1')
            numero.grid(row = contRows, column = 1)
            
            nomeFaixa = Label(mainArea, width = 60, text=str(row[0]), relief='solid', borderwidth = '1')
            nomeFaixa.grid(row = contRows, column = 2)

            album = Label(mainArea, width = 40, text=str(row[1]), relief='solid', borderwidth = '1')
            album.grid(row = contRows, column = 3)

            faixaN = Label(mainArea, width = 5, text=str(row[2]), relief='solid', borderwidth = '1')
            faixaN.grid(row = contRows, column = 4)

            gen = Label(mainArea, width = 10, text=str(row[3]), relief='solid', borderwidth = '1')
            gen.grid(row = contRows, column = 5)

            com = Label(mainArea, width = 20, text=str(row[4]), relief='solid', borderwidth = '1')
            com.grid(row = contRows, column = 6)

            temp = Label(mainArea, width = 10, text=convertTime(int(row[5])), relief='solid', borderwidth = '1')
            temp.grid(row = contRows, column = 7)

            tipgv = Label(mainArea, width = 10, text=str(row[6]), relief='solid', borderwidth = '1')
            tipgv.grid(row = contRows, column = 8)
            
            contRows = contRows + 1
            row = cur.fetchone()

    Quebra = Label(mainArea, width=170)
    Quebra.grid(row = contRows+1, column = 0, columnspan = 100)
    titulo2 = Button(mainArea, width=150, text='Adicionar nova faixa')
    titulo2["command"] = partial(novaFaixaemPlaylist, cod)
    titulo2.grid(row = contRows+2, column = 0, columnspan = 100)


def carregarAlgum(cod):
    mainArea.config(text="")
            
    widget_list = all_children(mainArea)
    for item in widget_list:
        item.destroy()

    cur.execute('EXEC pegar_nome_album '+str(cod))
    nome = cur.fetchone()

    titulo = Label(mainArea, width=150, text=str(nome[0]), relief = RIDGE, borderwidth = '3')
    titulo.grid(row = 0, column = 0, columnspan = 100)

    cur.execute('EXEC carregar_album '+str(cod))
    row = cur.fetchone()
    contRows = 1
    if(str(row) == 'None'):
        resp = Label(mainArea, width=150, text='Album vazio...', relief = 'solid', borderwidth = '1')
        resp.grid(row = 1, column = 0, columnspan = 100)
    
    else:
        while row:
            numero = Label(mainArea, width = 5, text=str(contRows), relief='solid', borderwidth = '1')
            numero.grid(row = contRows, column = 1)
            
            nomeFaixa = Label(mainArea, width = 60, text=str(row[0]), relief='solid', borderwidth = '1')
            nomeFaixa.grid(row = contRows, column = 2)

            faixaN = Label(mainArea, width = 5, text=str(row[2]), relief='solid', borderwidth = '1')
            faixaN.grid(row = contRows, column = 4)

            gen = Label(mainArea, width = 10, text=str(row[3]), relief='solid', borderwidth = '1')
            gen.grid(row = contRows, column = 5)

            com = Label(mainArea, width = 20, text=str(row[4]), relief='solid', borderwidth = '1')
            com.grid(row = contRows, column = 6)

            temp = Label(mainArea, width = 10, text=convertTime(int(row[5])), relief='solid', borderwidth = '1')
            temp.grid(row = contRows, column = 7)

            tipgv = Label(mainArea, width = 10, text=str(row[6]), relief='solid', borderwidth = '1')
            tipgv.grid(row = contRows, column = 8)
            
            contRows = contRows + 1
            row = cur.fetchone()

    Quebra = Label(mainArea, width=170)
    Quebra.grid(row = contRows+1, column = 0, columnspan = 100)
    titulo2 = Button(mainArea, width=150, text='Atualizar album')
    titulo2["command"] = partial(attAlbum, cod)
    titulo2.grid(row = contRows+2, column = 0, columnspan = 100)

def novaFaixaemPlaylist(cod):
    mainArea.config(text="")
    
    widget_list = all_children(mainArea)
    for item in widget_list:
        item.destroy()

    cur.execute('EXEC pegar_nome_playlist '+str(cod))
    nome = cur.fetchone()

    titulo = Label(mainArea, width=150, text="Selecione uma faixa para a playlist "+str(nome[0]), relief = RIDGE, borderwidth = '3')
    titulo.grid(row = 0, column = 0, columnspan = 100)

    tabN = Label(mainArea, width=5, text="#", relief = RIDGE, borderwidth = '3')
    tabN.grid(row = 1, column = 1)
    tabNome = Label(mainArea, width=60, text="nome", relief = RIDGE, borderwidth = '3')
    tabNome.grid(row = 1, column = 2)
    tabAlbum = Label(mainArea, width=40, text="Album", relief = RIDGE, borderwidth = '3')
    tabAlbum.grid(row = 1, column = 3)
    tabFaixaN = Label(mainArea, width=5, text="Faixa", relief = RIDGE, borderwidth = '3')
    tabFaixaN.grid(row = 1, column = 4)
    tabGen = Label(mainArea, width=10, text="Gênero", relief = RIDGE, borderwidth = '3')
    tabGen.grid(row = 1, column = 5)
    tabCom = Label(mainArea, width=20, text="Compositor", relief = RIDGE, borderwidth = '3')
    tabCom.grid(row = 1, column = 6)
    tabTemp = Label(mainArea, width=10, text="Tempo total", relief = RIDGE, borderwidth = '3')
    tabTemp.grid(row = 1, column = 7)
    tabTipgv = Label(mainArea, width=10, text="gravação", relief = RIDGE, borderwidth = '3')
    tabTipgv.grid(row = 1, column = 8)
    
    cur.execute('EXEC faixas_info')
    row = cur.fetchone()
    contRows = 2
    while row:
        numero = Label(mainArea, width = 5, text=str(contRows), relief='solid', borderwidth = '1')
        numero.grid(row = contRows, column = 1)
        
        nomeFaixa = Button(mainArea, width = 60, text=str(row[0]), relief='solid', borderwidth = '1')
        lista = [row[7],row[2],cod]
        nomeFaixa["command"] = partial(addFaixaEmPlaylist, lista)
        nomeFaixa.grid(row = contRows, column = 2)

        album = Label(mainArea, width = 40, text=str(row[1]), relief='solid', borderwidth = '1')
        album.grid(row = contRows, column = 3)

        faixaN = Label(mainArea, width = 5, text=str(row[2]), relief='solid', borderwidth = '1')
        faixaN.grid(row = contRows, column = 4)

        gen = Label(mainArea, width = 10, text=str(row[3]), relief='solid', borderwidth = '1')
        gen.grid(row = contRows, column = 5)

        com = Label(mainArea, width = 20, text=str(row[4]), relief='solid', borderwidth = '1')
        com.grid(row = contRows, column = 6)

        temp = Label(mainArea, width = 10, text=convertTime(int(row[5])), relief='solid', borderwidth = '1')
        temp.grid(row = contRows, column = 7)

        tipgv = Label(mainArea, width = 10, text=str(row[6]), relief='solid', borderwidth = '1')
        tipgv.grid(row = contRows, column = 8)
        
        contRows = contRows + 1
        row = cur.fetchone()



def addFaixaEmPlaylist(lista):
    codalbum = lista[0]
    numfaixa = lista[1]
    codplaylist = lista[2]
    print(codalbum, numfaixa, codplaylist)
    mainArea.config(text="")
    
    widget_list = all_children(mainArea)
    for item in widget_list:
        item.destroy()

    cur.execute('EXEC busca_faixa_playlist_reg '+str(codalbum)+', '+str(numfaixa)+', '+str(codplaylist))
    row = cur.fetchone()
    if(str(row) == 'None'):
        cur.execute('EXEC nova_faixa_em_playlist '+str(codalbum)+', '+str(numfaixa)+', '+str(codplaylist))
        cur.commit()

        titulo = Label(mainArea, width=150, text="Faixa adicionada!", relief = RIDGE, borderwidth = '3')
        titulo.grid(row = 0, column = 0, columnspan = 100)

    else:
        titulo = Label(mainArea, width=150, text="A faixa já existe nesta playlist!", relief = RIDGE, borderwidth = '3')
        titulo.grid(row = 0, column = 0, columnspan = 100)


def attAlbum(cod):
    mainArea.config(text="")
            
    widget_list = all_children(mainArea)
    for item in widget_list:
        item.destroy()

    cur.execute('EXEC pegar_nome_album '+str(cod))
    nome = cur.fetchone()

    titulo = Label(mainArea, width=150, text="Atualizar album: "+str(nome[0]), relief = RIDGE, borderwidth = '3')
    titulo.grid(row = 0, column = 0, columnspan = 100)

    tagCod = Label(mainArea, width = 40, text='Novo cógido:')
    tagCod.grid(row = 1, column = 0)

    entradaCod = Entry(mainArea, width = 40)
    entradaCod.grid(row = 1, column = 1)

    btnEnviarCod = Button(mainArea, width=20, text="enviar código")
    lista1 = [entradaCod, cod]
    btnEnviarCod["command"] = partial(attCodAlbum, lista1)
    btnEnviarCod.grid(row = 1, column = 2)

    tagDataCompra = Label(mainArea, width = 40, text='Nova data de compra:')
    tagDataCompra.grid(row = 2, column = 0)

    entradaDataCompra = Entry(mainArea, width = 40)
    entradaDataCompra.grid(row = 2, column = 1)

    btnEnviarDataCompra = Button(mainArea, width=20, text="enviar")
    lista2 = [entradaDataCompra, cod]
    btnEnviarDataCompra["command"] = partial(attDataCompAlbum, lista2)
    btnEnviarDataCompra.grid(row = 2, column = 2)

    tagDataGrav = Label(mainArea, width = 40, text='Novo data de gravação:')
    tagDataGrav.grid(row = 3, column = 0)

    entradaDataGrav = Entry(mainArea, width = 40)
    entradaDataGrav.grid(row = 3, column = 1)

    btnEnviarDataGrav = Button(mainArea, width=20, text="enviar")
    lista3 = [entradaDataGrav, cod]
    btnEnviarDataGrav["command"] = partial(attDataGravAlbum, lista3)
    btnEnviarDataGrav.grid(row = 3, column = 2)

    tagPreco = Label(mainArea, width = 40, text='Novo preço:')
    tagPreco.grid(row = 4, column = 0)

    entradaPreco = Entry(mainArea, width = 40)
    entradaPreco.grid(row = 4, column = 1)

    btnEnviarPreco = Button(mainArea, width=20, text="enviar")
    lista4 = [entradaPreco, cod]
    btnEnviarPreco["command"] = partial(attPrecoAlbum, lista4)
    btnEnviarPreco.grid(row = 4, column = 2)

    tagDesc = Label(mainArea, width = 40, text='Novo descrição:')
    tagDesc.grid(row = 5, column = 0)

    entradaDesc = Entry(mainArea, width = 40)
    entradaDesc.grid(row = 5, column = 1)

    btnEnviarDesc = Button(mainArea, width=20, text="enviar")
    lista = [entradaDesc, cod]
    btnEnviarDesc["command"] = partial(attdescAlbum, lista)
    btnEnviarDesc.grid(row = 5, column = 2)

    tagTipoCom = Label(mainArea, width = 40, text='Novo tipo de Compra:')
    tagTipoCom.grid(row = 6, column = 0)

    entradaTipoCom = Entry(mainArea, width = 40)
    entradaTipoCom.grid(row = 6, column = 1)

    btnEnviarTipoCom = Button(mainArea, width=20, text="enviar")
    lista5 = [entradaTipoCom, cod]
    btnEnviarTipoCom["command"] = partial(attTipoCompAlbum, lista5)
    btnEnviarTipoCom.grid(row = 6, column = 2)

    tagCodGrav = Label(mainArea, width = 40, text='Novo cógido de gravadora:')
    tagCod.grid(row = 7, column = 0)

    entradaCodGrav = Entry(mainArea, width = 40)
    entradaCodGrav.grid(row = 7, column = 1)

    btnEnviarCodGrav = Button(mainArea, width=20, text="enviar cod gravadora")
    lista6 = [entradaCodGrav, cod]
    btnEnviarCodGrav["command"] = partial(attCodGravAlbum, lista6)
    btnEnviarCodGrav.grid(row = 7, column = 2)


def attCodAlbum(lista):
    entrada = lista[0]
    novo = entrada.get()
    codAlbum = lista[1]

    mainArea.config(text="")
            
    widget_list = all_children(mainArea)
    for item in widget_list:
        item.destroy()

    cur.execute('EXEC check_exist_album '+str(novo))
    row = cur.fetchone()
    if(novo == ""):
        titulo = Label(mainArea, width=150, text="Entrada inválida!", relief = RIDGE, borderwidth = '3')
        titulo.grid(row = 0, column = 0, columnspan = 100)
        Quebra = Label(mainArea, width=170)
        Quebra.grid(row = 1, column = 0, columnspan = 100)
    
    elif (str(row) == 'None'):

        cur.execute('EXEC att_cod_album '+str(codAlbum)+', '+str(novo))
        cur.commit()
    
        titulo = Label(mainArea, width=150, text="Atributo atualizado!", relief = RIDGE, borderwidth = '3')
        titulo.grid(row = 0, column = 0, columnspan = 100)
        Quebra = Label(mainArea, width=170)
        Quebra.grid(row = 1, column = 0, columnspan = 100)

    else:
        titulo = Label(mainArea, width=150, text="Este cógido já existe!", relief = RIDGE, borderwidth = '3')
        titulo.grid(row = 0, column = 0, columnspan = 100)
        Quebra = Label(mainArea, width=170)
        Quebra.grid(row = 1, column = 0, columnspan = 100)


def attDataCompAlbum(lista):
    entrada = lista[0]
    novo = str(entrada.get())
    codAlbum = lista[1]

    mainArea.config(text="")
            
    widget_list = all_children(mainArea)
    for item in widget_list:
        item.destroy()
    if(novo == ""):
        titulo = Label(mainArea, width=150, text="Entrada inválida!", relief = RIDGE, borderwidth = '3')
        titulo.grid(row = 0, column = 0, columnspan = 100)
        Quebra = Label(mainArea, width=170)
        Quebra.grid(row = 1, column = 0, columnspan = 100)

    else:
        cur.execute('EXEC att_datadecompra_album '+str(codAlbum)+', '+str(novo))
        cur.commit()
        
        titulo = Label(mainArea, width=150, text="Atributo atualizado!", relief = RIDGE, borderwidth = '3')
        titulo.grid(row = 0, column = 0, columnspan = 100)
        Quebra = Label(mainArea, width=170)
        Quebra.grid(row = 1, column = 0, columnspan = 100)

def attDataGravAlbum(lista):
    entrada = lista[0]
    novo = entrada.get()
    codAlbum = lista[1]

    mainArea.config(text="")
            
    widget_list = all_children(mainArea)
    for item in widget_list:
        item.destroy()


    if(novo == ""):
        titulo = Label(mainArea, width=150, text="Entrada inválida!", relief = RIDGE, borderwidth = '3')
        titulo.grid(row = 0, column = 0, columnspan = 100)
        Quebra = Label(mainArea, width=170)
        Quebra.grid(row = 1, column = 0, columnspan = 100)

    else:
        cur.execute('EXEC att_datadegrav_album '+str(codAlbum)+', '+str(novo))
        cur.commit()
        
        titulo = Label(mainArea, width=150, text="Atributo atualizado!", relief = RIDGE, borderwidth = '3')
        titulo.grid(row = 0, column = 0, columnspan = 100)
        Quebra = Label(mainArea, width=170)
        Quebra.grid(row = 1, column = 0, columnspan = 100)

def attPrecoAlbum(lista):
    entrada = lista[0]
    novo = entrada.get()
    codAlbum = lista[1]

    mainArea.config(text="")
            
    widget_list = all_children(mainArea)
    for item in widget_list:
        item.destroy()

    if(novo == ""):
        titulo = Label(mainArea, width=150, text="Entrada inválida!", relief = RIDGE, borderwidth = '3')
        titulo.grid(row = 0, column = 0, columnspan = 100)
        Quebra = Label(mainArea, width=170)
        Quebra.grid(row = 1, column = 0, columnspan = 100)

    else:

        cur.execute('EXEC att_preco_album '+str(codAlbum)+', '+str(novo))
        cur.commit()
        
        titulo = Label(mainArea, width=150, text="Atributo atualizado!", relief = RIDGE, borderwidth = '3')
        titulo.grid(row = 0, column = 0, columnspan = 100)
        Quebra = Label(mainArea, width=170)
        Quebra.grid(row = 1, column = 0, columnspan = 100)

def attdescAlbum(lista):
    entrada = lista[0]
    novo = entrada.get()
    codAlbum = lista[1]

    mainArea.config(text="")
            
    widget_list = all_children(mainArea)
    for item in widget_list:
        item.destroy()

    if(novo == ""):
        titulo = Label(mainArea, width=150, text="Entrada inválida!", relief = RIDGE, borderwidth = '3')
        titulo.grid(row = 0, column = 0, columnspan = 100)
        Quebra = Label(mainArea, width=170)
        Quebra.grid(row = 1, column = 0, columnspan = 100)

    else:
        cur.execute('EXEC att_desc_album '+str(codAlbum)+', '+str(novo))
        cur.commit()
        
        titulo = Label(mainArea, width=150, text="Atributo atualizado!", relief = RIDGE, borderwidth = '3')
        titulo.grid(row = 0, column = 0, columnspan = 100)
        Quebra = Label(mainArea, width=170)
        Quebra.grid(row = 1, column = 0, columnspan = 100)

def attTipoCompAlbum(lista):
    entrada = lista[0]
    novo = entrada.get()
    codAlbum = lista[1]

    mainArea.config(text="")
            
    widget_list = all_children(mainArea)
    for item in widget_list:
        item.destroy()

    if(novo == ""):
        titulo = Label(mainArea, width=150, text="Entrada inválida!", relief = RIDGE, borderwidth = '3')
        titulo.grid(row = 0, column = 0, columnspan = 100)
        Quebra = Label(mainArea, width=170)
        Quebra.grid(row = 1, column = 0, columnspan = 100)

    else:

        cur.execute('EXEC att_tipocomp_album '+str(codAlbum)+', '+str(novo))
        cur.commit()
        
        titulo = Label(mainArea, width=150, text="Atributo atualizado!", relief = RIDGE, borderwidth = '3')
        titulo.grid(row = 0, column = 0, columnspan = 100)
        Quebra = Label(mainArea, width=170)
        Quebra.grid(row = 1, column = 0, columnspan = 100)

def attCodGravAlbum(lista):
    entrada = lista[0]
    novo = entrada.get()
    codAlbum = lista[1]

    mainArea.config(text="")
            
    widget_list = all_children(mainArea)
    for item in widget_list:
        item.destroy()

    cur.execute('EXEC check_exist_gravadora '+str(novo))
    row = cur.fetchone()
    if(novo == ""):
        titulo = Label(mainArea, width=150, text="Entrada inválida!", relief = RIDGE, borderwidth = '3')
        titulo.grid(row = 0, column = 0, columnspan = 100)
        Quebra = Label(mainArea, width=170)
        Quebra.grid(row = 1, column = 0, columnspan = 100)
    
    elif (str(row) == 'None'):
        titulo = Label(mainArea, width=150, text="Esta gravadora não existe!", relief = RIDGE, borderwidth = '3')
        Quebra = Label(mainArea, width=170)
        Quebra.grid(row = 1, column = 0, columnspan = 100)

    else:
        cur.execute('EXEC att_codgrav_album '+str(codAlbum)+', '+str(novo))
        cur.commit()
        
        titulo = Label(mainArea, width=150, text="Atributo atualizado!", relief = RIDGE, borderwidth = '3')
        titulo.grid(row = 0, column = 0, columnspan = 100)
        Quebra = Label(mainArea, width=170)
        Quebra.grid(row = 1, column = 0, columnspan = 100)

def novaAlbumCampo():
    mainArea.config(text="")
    
    widget_list = all_children(mainArea)
    for item in widget_list:
        item.destroy()

    titulo = Label(mainArea, width=150, text="Digite o nome de um album existente!", relief = RIDGE, borderwidth = '3')
    titulo.grid(row = 0, column = 0, columnspan = 100)

    tituloEntrada = Label(mainArea, width = 10, text='Nome:')
    tituloEntrada.grid(row = 1, column = 0)

    entrada = Entry(mainArea)
    entrada.grid(row = 1, column = 1)

    btnEnviarNomePlaylist = Button(mainArea, width=20, text="Pesquisar")
    btnEnviarNomePlaylist["command"] = partial(buscarCod, entrada)
    #btEnviarNomePlaylist["command"] = partial(enviarNomePlaylist, entrada)
    btnEnviarNomePlaylist.grid(row = 1, column = 2)

def buscarCod(entrada):
    nome = entrada.get()
    if(nome != ""):
        cur.execute('EXEC pegar_cod_album '+str(nome))
        cod = cur.fetchone()
        if(str(cod) == 'None'):
                
            widget_list = all_children(mainArea)
            for item in widget_list:
                item.destroy()

            titulo = Label(mainArea, width=150, text="Nenhum resultado encontrado!", relief = RIDGE, borderwidth = '3')
            titulo.grid(row = 0, column = 0, columnspan = 100)

        else:
            attAlbum(cod[0])


#Interface root
janela = Tk()

janela.geometry('800x600+0+0')
janela.title("SpotPer")

player = Label(janela, text="bt player aqui", bg="blue")
player.pack(side=BOTTOM, fill=X)

btplay = Button(player, width=20, text="play")
btplay.pack(side=BOTTOM, fill=Y)

menu = Label(janela, width=20, text="Menu", bg="white")
menu.pack(side=LEFT, fill=Y)

mainArea = Label(janela, height = 60, text="SELECIONE UMA OPÇÃO AO LADO")
mainArea.pack(side=TOP, fill=BOTH)

btnFaixas = Button(menu, width=20, text="FAIXAS", command=getInfoFaixas)
btnFaixas.pack()

btnAlbuns = Button(menu, width=20, text="ALBUNS", command=getInfoAlbuns)
btnAlbuns.pack()
    
btnPlaylists = Button(menu, width=20, text="PLAYLISTS", command=getInfoPlaylists)
btnPlaylists.pack()

janela.mainloop()

cur.commit()
cur.close()
con.close()
