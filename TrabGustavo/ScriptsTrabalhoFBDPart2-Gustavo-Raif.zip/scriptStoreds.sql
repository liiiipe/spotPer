-- Script de Views e Stored Procedures para APP SpotPer

USE BDSpotPer;

CREATE PROCEDURE faixas_info
AS
SELECT faixa.descricao AS 'nome',
descricao_album AS 'album',
faixa.numero_faixa AS 'faixa',
composicao.descricao AS 'genero',
nome_compositor AS 'compositor',
tempo_de_execucao,
tipo_de_gravacao, album.cod_album
FROM faixa INNER JOIN album
ON faixa.cod_album = album.cod_album INNER JOIN composicao
ON faixa.cod_composicao = composicao.cod_composicao LEFT OUTER JOIN faixa_compositor
ON faixa_compositor.cod_album = faixa.cod_album AND faixa_compositor.numero_faixa = faixa.numero_faixa LEFT OUTER JOIN compositor
ON compositor.cod_compositor = faixa_compositor.cod_compositor

EXEC faixas_info

CREATE PROCEDURE albuns_info
AS
SELECT descricao_album AS 'nome', data_de_gravacao, data_de_compra, preco_de_compra AS 'valor', tipo_de_compra, gravadora.nome_gravadora AS 'gravadora', album.cod_album FROM album LEFT OUTER JOIN gravadora
ON gravadora.cod_gravadora = album.cod_gravadora

EXEC albuns_info

CREATE PROCEDURE playlists_info
AS
SELECT nome_da_playlist, data_de_criacao, numero_de_tocadas, data_ultima_toca, COUNT(DISTINCT(CONCAT(cod_album, numero_faixa))) AS 'n� de musicas', playlist.cod_playlist FROM playlist LEFT OUTER JOIN faixa_playlist
ON playlist.cod_playlist = faixa_playlist.cod_playlist
GROUP BY nome_da_playlist, data_de_criacao, numero_de_tocadas, data_ultima_toca, playlist.cod_playlist

EXEC playlists_info

CREATE PROCEDURE crear_nova_playlist @nome VARCHAR(50)
AS
INSERT INTO playlist (nome_da_playlist) VALUES(@nome)

--EXEC crear_nova_playlist teste

CREATE PROCEDURE carregar_playlist @cod INT
AS
SELECT faixa.descricao AS 'musisca',
descricao_album AS 'album',
faixa.numero_faixa AS 'faixa',
composicao.descricao AS 'genero',
nome_compositor AS 'compositor',
tempo_de_execucao,
tipo_de_gravacao, playlist.cod_playlist FROM playlist INNER JOIN faixa_playlist
ON playlist.cod_playlist = faixa_playlist.cod_playlist INNER JOIN faixa
ON faixa.cod_album = faixa_playlist.cod_album AND faixa.numero_faixa = faixa_playlist.numero_faixa INNER JOIN album
ON faixa.cod_album = album.cod_album INNER JOIN composicao
ON faixa.cod_composicao = composicao.cod_composicao LEFT OUTER JOIN faixa_compositor
ON faixa_compositor.cod_album = faixa.cod_album AND faixa_compositor.numero_faixa = faixa.numero_faixa LEFT OUTER JOIN compositor
ON compositor.cod_compositor = faixa_compositor.cod_compositor WHERE playlist.cod_playlist = @cod

CREATE PROCEDURE carregar_album @cod INT
AS
SELECT faixa.descricao AS 'musisca',
descricao_album AS 'album',
faixa.numero_faixa AS 'faixa',
composicao.descricao AS 'genero',
nome_compositor AS 'compositor',
tempo_de_execucao,
tipo_de_gravacao FROM album LEFT OUTER JOIN faixa
ON faixa.cod_album = album.cod_album INNER JOIN composicao
ON faixa.cod_composicao = composicao.cod_composicao LEFT OUTER JOIN faixa_compositor
ON faixa_compositor.cod_album = faixa.cod_album AND faixa_compositor.numero_faixa = faixa.numero_faixa LEFT OUTER JOIN compositor
ON compositor.cod_compositor = faixa_compositor.cod_compositor WHERE album.cod_album = @cod

CREATE PROCEDURE pegar_nome_album @cod INT
AS
SELECT descricao_album FROM album WHERE album.cod_album = @cod

CREATE PROCEDURE pegar_nome_playlist @cod INT
AS
SELECT nome_da_playlist FROM playlist WHERE cod_playlist = @cod

EXEC playlists_info

CREATE PROCEDURE nova_faixa_em_playlist @codalbum INT, @numfaixa INT, @codplaylist INT
AS
INSERT INTO faixa_playlist (cod_album, numero_faixa, cod_playlist)
VALUES(@codalbum, @numfaixa, @codplaylist)

CREATE PROCEDURE busca_faixa_playlist_reg @codalbum INT, @numfaixa INT, @codplaylist INT
AS
SELECT cod_album FROM faixa_playlist WHERE cod_album = @codalbum AND numero_faixa = @numfaixa AND cod_playlist = @codplaylist

CREATE PROCEDURE pegar_cod_album @descricao VARCHAR(50)
AS
SELECT cod_album FROM album WHERE descricao_album like '%'+@descricao+'%'

EXEC pegar_cod_album 'DDD'



CREATE PROCEDURE check_exist_album @cod INT
AS
SELECT cod_album FROM album WHERE cod_album = @cod

EXEC check_exist_album 40

CREATE PROCEDURE att_cod_album @cod INT, @newcod INT
AS
UPDATE album
SET cod_album = @newcod
WHERE cod_album = @cod




CREATE PROCEDURE att_datadecompra_album @cod INT, @newdata VARCHAR(12)
AS
UPDATE album
SET data_de_compra = @newdata
WHERE cod_album = @cod



CREATE PROCEDURE att_datadegrav_album @cod INT, @newdata VARCHAR(12)
AS
UPDATE album
SET data_de_gravacao = @newdata
WHERE cod_album = @cod



CREATE PROCEDURE att_preco_album @cod INT, @newpreco INT
AS
UPDATE album
SET preco_de_compra = @newpreco
WHERE cod_album = @cod



CREATE PROCEDURE att_desc_album @cod INT, @newdesc VARCHAR(50)
AS
UPDATE album
SET descricao_album = @newdesc
WHERE cod_album = @cod


CREATE PROCEDURE att_tipocomp_album @cod INT, @newtipocomp VARCHAR(50)
AS
UPDATE album
SET tipo_de_compra = @newtipocomp
WHERE cod_album = @cod


CREATE PROCEDURE att_codgrav_album @cod INT, @newcodgrav INT
AS
UPDATE album
SET cod_gravadora = @newcodgrav
WHERE cod_album = @cod


CREATE PROCEDURE check_exist_gravadora @cod INT
AS
SELECT cod_gravadora FROM gravadora WHERE cod_gravadora = @cod

EXEC check_exist_gravadora 1000
