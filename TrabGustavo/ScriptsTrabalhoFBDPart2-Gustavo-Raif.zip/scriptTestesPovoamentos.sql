USE BDSpotPer;

SELECT * FROM playlist
SELECT * FROM gravadora
SELECT * FROM periodo_musical
SELECT * FROM compositor
SELECT * FROM album
SELECT * FROM composicao
SELECT * FROM faixa
SELECT * FROM faixa_playlist
SELECT * FROM faixa_compositor

--SELECT * FROM v1
--DROP VIEW v1

SELECT * FROM albuns_altor_f('Bach')

--#Povoamento

--INSERT INTO playlist (nome_da_playlist) VALUES('playlist_1album')

--INSERT INTO playlist (nome_da_playlist) VALUES('playlist_2albuns')

--INSERT INTO playlist (nome_da_playlist) VALUES('SegundaPlaylistBach')

--INSERT INTO playlist (nome_da_playlist) VALUES('playlistDvorack')

--INSERT INTO playlist (nome_da_playlist) VALUES('concertoBarroco')

INSERT INTO gravadora (cod_gravadora, nome_gravadora, endereco, site_gravadora)
VALUES (1, 'Naxos', 'Hong Kong', 'https://www.naxos.com/')

INSERT INTO gravadora (cod_gravadora, nome_gravadora, endereco, site_gravadora)
VALUES (2, 'Sony Music Br', 'S�o Paulo, S�o Paulo', 'https://www.sonymusic.com.br/')

INSERT INTO gravadora (cod_gravadora, nome_gravadora, endereco, site_gravadora)
VALUES (3,'Deutsche Grammophon', ' Han�ver, Alemanha', 'https://www.deutschegrammophon.com/')

INSERT INTO periodo_musical (cod_periodo, intervalo, descricao)
VALUES(1, 'sec. XVII a sec XVIII', 'Barroco')

INSERT INTO periodo_musical (cod_periodo, intervalo, descricao)
VALUES(2, 'sec. XIX', 'Romantismo')

INSERT INTO compositor (cod_compositor, local_de_nascimento, nome_compositor, data_de_morte, data_de_nascimento, cod_periodo)
VALUES(1, 'Eisenach, Alemanha', 'Johann Sebastian Bach','28-07-1750', '21-03-1685', 1)

INSERT INTO compositor (cod_compositor, local_de_nascimento, nome_compositor, data_de_morte, data_de_nascimento, cod_periodo)
VALUES(2, 'Nelahozeves, Imp�rio Austr�aco', 'Anton�n Leopold Dvo?�k','01-05-1904', '08-10-1841', 2)

INSERT INTO album (cod_album, data_de_compra, data_de_gravacao, preco_de_compra, descricao_album, tipo_de_compra, cod_gravadora)
VALUES (1, '02-12-2018', '29-08-2018', 60, 'Yellow Lounge', 'Download', 3)

INSERT INTO album (cod_album, data_de_compra, data_de_gravacao, preco_de_compra, descricao_album, tipo_de_compra, cod_gravadora)
VALUES (2, '02-12-2018', '26-10-2018', 80, 'Bach333', 'F�sica', 3)

INSERT INTO album (cod_album, data_de_compra, data_de_gravacao, preco_de_compra, descricao_album, tipo_de_compra, cod_gravadora)
VALUES(3, '03-12-2018', '03-12-2018', 90, 'OnlyDDD', 'Download', 2)

INSERT INTO album (cod_album, data_de_compra, data_de_gravacao, preco_de_compra, descricao_album, tipo_de_compra, cod_gravadora)
VALUES(4, '25-12-2017', '03-12-2018', 50, 'AlbumVazio', 'F�sica', 1)

INSERT INTO composicao VALUES(1, 'Concerto')

INSERT INTO composicao VALUES(2, 'Suite')

INSERT INTO composicao VALUES(3, '�pera')

INSERT INTO faixa (numero_faixa, cod_album, cod_composicao, descricao, tempo_de_execucao, tipo_de_gravacao)
VALUES (1, 1, 1, 'Grande valse brillante', 320, 'ADD')

INSERT INTO faixa (numero_faixa, cod_album, cod_composicao, descricao, tempo_de_execucao, tipo_de_gravacao)
VALUES (4, 2, 1, 'Brandenburg Concerto No. 3 in G Major', 690, 'ADD')

INSERT INTO faixa (numero_faixa, cod_album, cod_composicao, descricao, tempo_de_execucao, tipo_de_gravacao)
VALUES (5, 2, 2, 'The Cello Suites', 530, 'DDD')

INSERT INTO faixa (numero_faixa, cod_album, cod_composicao, descricao, tempo_de_execucao, tipo_de_gravacao)
VALUES (5, 3, 2, 'The Cello Suites', 530, 'DDD')

INSERT INTO faixa (numero_faixa, cod_album, cod_composicao, descricao, tempo_de_execucao, tipo_de_gravacao)
VALUES (3, 1, 3, 'The Devil and Kate (?ert a K�?a)', 7200, 'DDD')

INSERT INTO faixa (numero_faixa, cod_album, cod_composicao, descricao, tempo_de_execucao, tipo_de_gravacao)
VALUES (7, 2, 1, 'The Violin Concertos', 7200, 'DDD')

INSERT INTO faixa (numero_faixa, cod_album, cod_composicao, descricao, tempo_de_execucao, tipo_de_gravacao)
VALUES (8, 2, 1, 'Nach Italienischen Gusto', 720, 'DDD')

INSERT INTO faixa_playlist (cod_album, numero_faixa, cod_playlist)
VALUES (1, 1, 1)

INSERT INTO faixa_playlist (cod_album, numero_faixa, cod_playlist)
VALUES (1, 1, 2)

INSERT INTO faixa_playlist (cod_album, numero_faixa, cod_playlist)
VALUES (2, 4, 2)

INSERT INTO faixa_playlist (cod_album, numero_faixa, cod_playlist)
VALUES (2, 5, 2)

INSERT INTO faixa_playlist (cod_album, numero_faixa, cod_playlist)
VALUES (1, 3, 6)

INSERT INTO faixa_playlist (cod_album, numero_faixa, cod_playlist)
VALUES (1, 3, 6)

INSERT INTO faixa_playlist (cod_album, numero_faixa, cod_playlist)
VALUES (2, 5, 5)

INSERT INTO faixa_playlist (cod_album, numero_faixa, cod_playlist)
VALUES (2, 7, 7)

INSERT INTO faixa_playlist (cod_album, numero_faixa, cod_playlist)
VALUES (2, 8, 7)

INSERT INTO faixa_compositor (cod_compositor, cod_album, numero_faixa)
VALUES (1, 2, 5)

INSERT INTO faixa_compositor (cod_compositor, cod_album, numero_faixa)
VALUES (2, 1, 3)

INSERT INTO faixa_compositor (cod_compositor, cod_album, numero_faixa)
VALUES (1, 2, 7)

INSERT INTO faixa_compositor (cod_compositor, cod_album, numero_faixa)
VALUES (1, 2, 8)


-- Teste para preco_album_limit_TR (trigger)
/*INSERT INTO album (cod_album, data_de_compra, data_de_gravacao, preco_de_compra, descricao_album, tipo_de_compra, cod_gravadora)
VALUES (3, '02-12-2018', '26-10-2018', 300, 'Teste', 'F�sica', 1)*/

-- Teste para TR_album_faixa_periodo_tipograva (trigger)
/*INSERT INTO faixa_compositor (cod_compositor, cod_album, numero_faixa)
VALUES (1, 2, 4)*/


	SELECT nome_da_playlist, cod_album, COUNT_BIG(*) AS qtd_albuns FROM playlist INNER JOIN
	faixa_playlist ON playlist.cod_playlist = faixa_playlist.cod_playlist
	GROUP BY nome_da_playlist, cod_album

	SELECT nome_da_playlist, COUNT_BIG(DISTINCT faixa_playlistP.cod_album) AS qtd_albuns FROM dbo.playlist INNER JOIN
	dbo.faixa_playlist AS faixa_playlistP ON playlist.cod_playlist = faixa_playlistP.cod_playlist
	--WHERE NOT EXISTS (SELECT faixa_playlist.numero_faixa FROM dbo.faixa_playlist WHERE faixa_playlist.numero_faixa > faixa_playlistP.numero_faixa AND faixa_playlist.cod_album = faixa_playlistP.cod_album)
	GROUP BY nome_da_playlist

	SELECT nome_da_playlist, COUNT_BIG(faixa_playlistP.cod_album) AS qtd_albuns FROM dbo.playlist INNER JOIN
	dbo.faixa_playlist AS faixa_playlistP ON playlist.cod_playlist = faixa_playlistP.cod_playlist INNER JOIN album
	ON album.cod_album = faixa_playlistP.cod_album
	GROUP BY nome_da_playlist


	SELECT nome_da_playlist,playlist.cod_playlist, faixa_playlist.cod_playlist, faixa_playlist.cod_album, album.cod_album, faixa.cod_album, faixa.numero_faixa FROM playlist INNER JOIN faixa_playlist
	ON playlist.cod_playlist = faixa_playlist.cod_playlist INNER JOIN album 
	ON album.cod_album = faixa_playlist.cod_album INNER JOIN faixa
	ON album.cod_album = faixa.cod_album AND faixa_playlist.numero_faixa = faixa.numero_faixa


SELECT nome_da_playlist, COUNT(*) AS qtd_albuns FROM playlist INNER JOIN faixa_playlist
ON playlist.cod_playlist = faixa_playlist.cod_playlist
GROUP BY nome_da_playlist
